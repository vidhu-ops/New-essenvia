Open Essentra-IIDATECH-Complete-Design-Pack.html in Chrome, Safari, or Edge.
Keep iidatech-logo.png in the same folder as the HTML file.
